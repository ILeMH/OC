==========================================================
		Pour regarder le wireframe :
==========================================================

* Pour un affichage sur PC ou PC portable, ouvrir la page home.html
* Pour un affichage t�l�phone, ouvrir la page home_portable.html

==========================================================
		Agir avec la wireframe :
==========================================================

On peut l'utiliser comme un vrai site en utilisant les liens.
Comme il ne s'agit que d'un wireframe, rien de rentre en vigeur, ce n'est qu'une d�monstration.



Revolution digitale.