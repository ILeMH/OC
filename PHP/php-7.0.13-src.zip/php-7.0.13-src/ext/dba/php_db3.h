#ifndef PHP_DB3_H
#define PHP_DB3_H

#if DBA_DB3

#include "php_dba.h"

DBA_FUNCS(db3);

#endif

#endif
