/* 
Activité 1
*/

// Liste des liens Web à afficher. Un lien est défini par :
// - son titre
// - son URL
// - son auteur (la personne qui l'a publié)
var listeLiens = [
    {
        titre: "So Foot",
        url: " http://sofoot.com",
        auteur: "yann.usaille"
    },
    {
        titre: "Guide d'autodéfense numérique",
        url: " http://guide.boum.org",
        auteur: "paulochon"
    },
    {
        titre: "L'encyclopédie en ligne Wikipedia",
        url: " http://Wikipedia.org",
        auteur: "annie.zette"
    }
];

/*-----------------------------------------------------------------------------
/////////////////////////	création de la page vierge	///////////////////////
------------------------------------------------------------------------------*/

var papa = document.getElementById("contenu");
var liste = document.createElement("ul");
papa.appendChild(liste);

var enumeration1 = document.createElement("li");
enumeration1.classList.add("lien");
var enumeration2 = document.createElement("li");
enumeration2.classList.add("lien");
var enumeration3 = document.createElement("li");
enumeration3.classList.add("lien");

liste.appendChild(enumeration1);
liste.appendChild(enumeration2);
liste.appendChild(enumeration3);


var enumeration11 = document.createElement("li");
enumeration11.id = "enumeration11";
var enumeration12 = document.createElement("li");
enumeration12.id = "enumeration12";
var enumeration21 = document.createElement("li");
enumeration21.id = "enumeration21";
var enumeration22 = document.createElement("li");
enumeration22.id = "enumeration22";
var enumeration31 = document.createElement("li");
enumeration31.id = "enumeration31";
var enumeration32 = document.createElement("li");
enumeration32.id = "enumeration32";

enumeration1.appendChild(enumeration11);
enumeration1.appendChild(enumeration12);

enumeration2.appendChild(enumeration21);
enumeration2.appendChild(enumeration22);

enumeration3.appendChild(enumeration31);
enumeration3.appendChild(enumeration32);

/*---------------------------------------------------------------------------
////////////////////////////////	première partie		/////////////////////
----------------------------------------------------------------------------*/

var url1 = document.createTextNode(listeLiens[0].url);
var lien1 = document.createElement("a");
lien1.id = "lien1";
lien1.href = listeLiens[0].url;
lien1.textContent = listeLiens[0].titre;
var auteur1 = document.createTextNode("Ajouté par : " + listeLiens[0].auteur);

enumeration11.appendChild(url1);
document.getElementById("enumeration11").insertBefore(lien1, url1);
enumeration12.appendChild(auteur1);

/*-----------------------------------------------------------------------------
///////////////////////////////		deuxieme partie		///////////////////////
------------------------------------------------------------------------------*/

var url2 = document.createTextNode(listeLiens[0].url);
var lien2 = document.createElement("a");
lien2.id = "lien2";
lien2.href = listeLiens[1].url;
lien2.textContent = listeLiens[1].titre;
var auteur2 = document.createTextNode("Ajouté par : " + listeLiens[1].auteur);

enumeration21.appendChild(url2);
document.getElementById("enumeration21").insertBefore(lien2, url2);
enumeration22.appendChild(auteur2);

/*------------------------------------------------------------------------------
///////////////////////////////		troisieme partie	////////////////////////
-------------------------------------------------------------------------------*/

var url3 = document.createTextNode(listeLiens[2].url);
var lien3 = document.createElement("a");
lien3.id = "lien3";
lien3.href = listeLiens[2].url;
lien3.textContent = listeLiens[2].titre;
var auteur3 = document.createTextNode("Ajouté par : " + listeLiens[2].auteur);

enumeration31.appendChild(url3);
document.getElementById("enumeration31").insertBefore(lien3, url3);
enumeration32.appendChild(auteur3);

/*-------------------------------------------------------------------------------
///////////////////////////		Style et mise en page	/////////////////////////
--------------------------------------------------------------------------------*/

var puceS = document.querySelectorAll("li");
var i;
for (i = 0 ; i < puceS.length; i++) {
	puceS[i].style.listStyleType = "none";
}

var premierTitre = document.getElementById("lien1");
premierTitre.style.color = ("#428bca");
premierTitre.style.fontSize = "110%";
premierTitre.style.fontWeight = "bold";
premierTitre.style.textDecoration ="none";

var deuxiemeTitre = document.getElementById("lien2");
deuxiemeTitre.style.color = ("#428bca");
deuxiemeTitre.style.fontSize = "110%";
deuxiemeTitre.style.fontWeight = "bold";
deuxiemeTitre.style.textDecoration ="none";

var troisiemeTitre = document.getElementById("lien3");
troisiemeTitre.style.color = ("#428bca");
troisiemeTitre.style.fontSize = "110%";
troisiemeTitre.style.fontWeight = "bold";
troisiemeTitre.style.textDecoration ="none";